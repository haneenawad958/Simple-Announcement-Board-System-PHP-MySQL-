<?php 
require 'includes/db.php'; 
require 'includes/functions.php'; 
if(!isLoggedIn()) header("Location: login.php");
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="assets/style.css"></head>
<body>
<div class="container">
    <nav>
        <a href="index.php">Home</a>
        <a href="logout.php" style="float:right">Logout</a>
    </nav>

    <h2>Dashboard</h2>
    <a href="announcement_form.php" class="btn"> + Add New Announcement</a>
    <hr>

    <h3>Your Announcements / Manage</h3>
    <table width="100%" border="1" style="border-collapse: collapse;">
        <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Date</th>
            <th>Action</th>
        </tr>
        <?php
        // If Admin, view all. If User, view only own.
        if(isAdmin()) {
            $sql = "SELECT a.*, u.first_name FROM announcements a JOIN users u ON a.user_id = u.id";
        } else {
            $id = $_SESSION['user_id'];
            $sql = "SELECT a.*, u.first_name FROM announcements a JOIN users u ON a.user_id = u.id WHERE a.user_id = $id";
        }
        
        $result = $conn->query($sql);
        while($row = $result->fetch_assoc()):
        ?>
        <tr>
            <td><?php echo e($row['title']); ?></td>
            <td><?php echo e($row['first_name']); ?></td>
            <td><?php echo $row['created_at']; ?></td>
            <td>
                <!-- Only owner or admin can edit/delete -->
                <a href="announcement_form.php?id=<?php echo $row['id']; ?>" class="btn">Edit</a>
                <a href="actions/delete_action.php?type=announcement&id=<?php echo $row['id']; ?>" class="btn btn-danger" onclick="return confirm('Delete?');">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <?php if(isAdmin()): ?>
    <hr>
    <h3>Admin: Manage Users</h3>
    <table width="100%" border="1" style="border-collapse: collapse;">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Action</th>
        </tr>
        <?php
        $u_result = $conn->query("SELECT * FROM users");
        while($u = $u_result->fetch_assoc()):
        ?>
        <tr>
            <td><?php echo e($u['first_name'] . ' ' . $u['last_name']); ?></td>
            <td><?php echo e($u['email']); ?></td>
            <td><?php echo e($u['role']); ?></td>
            <td>
                <?php if($u['id'] != $_SESSION['user_id']): ?>
                    <a href="actions/delete_action.php?type=user&id=<?php echo $u['id']; ?>" class="btn btn-danger" onclick="return confirm('Delete user?');">Delete</a>
                <?php else: echo " (You) "; endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <?php endif; ?>
</div>
</body>
</html>