<?php require 'includes/db.php'; require 'includes/functions.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Announcement Board</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="container">
    <nav>
        <a href="index.php">Home</a>
        <?php if(isLoggedIn()): ?>
            <a href="dashboard.php">Dashboard</a>
            <a href="profile.php">My Profile</a>
            <a href="logout.php" style="float:right">Logout (<?php echo e($_SESSION['name']); ?>)</a>
        <?php else: ?>
            <a href="login.php" style="float:right">Login</a>
            <a href="register.php" style="float:right">Register</a>
        <?php endif; ?>
    </nav>

    <h1>Latest Announcements</h1>
    <?php
    $sql = "SELECT a.*, u.first_name, u.last_name, u.profile_image 
            FROM announcements a 
            JOIN users u ON a.user_id = u.id 
            ORDER BY a.created_at DESC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo '<div class="card">';
            // Bonus: Show User Image
            if($row['profile_image']) {
                $p_img = $row['profile_image'] == 'default_user.png' ? 'default_user.png' : 'assets/uploads/'.$row['profile_image'];
                // Only show path if needed, for simplicity let's just show text data
            }
            
            echo '<h3>' . e($row['title']) . '</h3>';
            echo '<small>Posted by: ' . e($row['first_name'] . ' ' . $row['last_name']) . ' on ' . $row['created_at'] . '</small>';
            echo '<p>' . nl2br(e($row['body'])) . '</p>';
            
            // Bonus: Show Announcement Image
            if(!empty($row['image'])) {
                echo '<img src="assets/uploads/' . e($row['image']) . '" style="max-width:100%; max-height:300px;">';
            }
            echo '</div>';
        }
    } else {
        echo "<p>No announcements yet.</p>";
    }
    ?>
</div>
</body>
</html>