<?php
require 'includes/db.php';
require 'includes/functions.php';
if(!isLoggedIn()) header("Location: login.php");

$uid = $_SESSION['user_id'];

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $fname = $_POST['first_name'];
    $lname = $_POST['last_name'];
    $newImg = uploadImage($_FILES['profile_image']);

    $sql = "UPDATE users SET first_name=?, last_name=?";
    if($newImg) $sql .= ", profile_image='$newImg'";
    $sql .= " WHERE id=?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $fname, $lname, $uid);
    $stmt->execute();
    
    // Update session name
    $_SESSION['name'] = $fname;
    echo "<script>alert('Profile Updated');</script>";
}

$u = $conn->query("SELECT * FROM users WHERE id=$uid")->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="assets/style.css"></head>
<body>
<div class="container">
    <nav><a href="index.php">Home</a></nav>
    <h2>Edit Profile</h2>
    <form method="POST" enctype="multipart/form-data">
        <label>First Name:</label>
        <input type="text" name="first_name" value="<?php echo e($u['first_name']); ?>" required>
        <label>Last Name:</label>
        <input type="text" name="last_name" value="<?php echo e($u['last_name']); ?>" required>
        
        <label>Profile Image:</label>
        <input type="file" name="profile_image">
        <?php if($u['profile_image'] && $u['profile_image'] != 'default_user.png'): ?>
            <img src="assets/uploads/<?php echo $u['profile_image']; ?>" class="thumb">
        <?php endif; ?>
        
        <button type="submit" class="btn">Update Profile</button>
    </form>
</div>
</body>
</html>