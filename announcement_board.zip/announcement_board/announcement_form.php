<?php
require 'includes/db.php';
require 'includes/functions.php';
if(!isLoggedIn()) header("Location: login.php");

$id = ''; $title = ''; $body = ''; $image = '';
$isEdit = false;

// Check if Edit Mode
if (isset($_GET['id'])) {
    $isEdit = true;
    $id = $_GET['id'];
    
    // Check permission
    $stmt = $conn->prepare("SELECT * FROM announcements WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $data = $res->fetch_assoc();

    // Security check: only owner or admin can edit
    if($data['user_id'] != $_SESSION['user_id'] && !isAdmin()){
        die("Unauthorized access");
    }

    $title = $data['title'];
    $body = $data['body'];
    $image = $data['image'];
}

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $body = $_POST['body'];
    $newImage = uploadImage($_FILES['image']); // From functions.php

    if ($isEdit) {
        $sql = "UPDATE announcements SET title=?, body=?";
        if($newImage) $sql .= ", image='$newImage'"; // Update image only if new one uploaded
        $sql .= " WHERE id=?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $title, $body, $id);
    } else {
        $uid = $_SESSION['user_id'];
        $imgName = $newImage ? $newImage : NULL;
        $stmt = $conn->prepare("INSERT INTO announcements (user_id, title, body, image) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $uid, $title, $body, $imgName);
    }

    if($stmt->execute()) header("Location: dashboard.php");
}
?>

<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="assets/style.css"></head>
<body>
<div class="container">
    <h2><?php echo $isEdit ? 'Edit' : 'Add'; ?> Announcement</h2>
    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="title" value="<?php echo e($title); ?>" placeholder="Title" required>
        <textarea name="body" rows="5" placeholder="Content" required><?php echo e($body); ?></textarea>
        
        <label>Image (Optional):</label>
        <input type="file" name="image">
        <?php if($image): ?>
            <p>Current Image:</p>
            <img src="assets/uploads/<?php echo $image; ?>" class="thumb">
        <?php endif; ?>
        
        <br>
        <button type="submit" class="btn">Save</button>
        <a href="dashboard.php" class="btn btn-danger">Cancel</a>
    </form>
</div>
</body>
</html>