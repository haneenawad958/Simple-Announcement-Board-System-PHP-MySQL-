<?php
require '../includes/db.php';
require '../includes/functions.php';
if(!isLoggedIn()) header("Location: ../login.php");

$type = $_GET['type']; // 'user' or 'announcement'
$id   = intval($_GET['id']);

if ($type == 'announcement') {
    // Check permission
    $check = $conn->query("SELECT user_id FROM announcements WHERE id=$id")->fetch_assoc();
    if (isAdmin() || $check['user_id'] == $_SESSION['user_id']) {
        $conn->query("DELETE FROM announcements WHERE id=$id");
    }
} elseif ($type == 'user' && isAdmin()) {
    // Admin only
    $conn->query("DELETE FROM users WHERE id=$id");
}

header("Location: ../dashboard.php");
?>