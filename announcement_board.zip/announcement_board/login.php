<?php require 'includes/functions.php'; ?>
<!DOCTYPE html>
<html>
<head><link rel="stylesheet" href="assets/style.css"></head>
<body>
<div class="container">
    <h2>Login</h2>
    <?php if(isset($_GET['msg'])) echo '<div class="alert">Registration successful! Please login.</div>'; ?>
    <form action="actions/login_action.php" method="POST">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" class="btn">Login</button>
    </form>
    <p>No account? <a href="register.php">Register here</a></p>
    <p><a href="index.php">Back to Home</a></p>
</div>
</body>
</html>